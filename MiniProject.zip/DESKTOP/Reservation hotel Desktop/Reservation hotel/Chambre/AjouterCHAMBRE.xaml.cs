﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace Reservation_hotel.Chambre
{
    public partial class AjouterCHAMBRE : Window
    {
        string connectionString = "Server=DESKTOP-2K5N25U\\SQLEXPRESS;Database=HotelDb;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;";
        public AjouterCHAMBRE()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateRoomAvailability();
        }
        private void UpdateRoomAvailability()
        {
            string query = "SELECT NumeroChambre, Disponibilite FROM Chambres";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        int roomNumber = reader.GetInt32(0);
                        bool availability = reader.GetBoolean(1);
                        ChangeRoomLabelBackground(roomNumber, availability);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void ChangeRoomLabelBackground(int roomNumber, bool isAvailable)
        {
            Label roomLabel = GetRoomLabel(roomNumber);

            if (roomLabel != null)
            {
                roomLabel.Background = isAvailable ? System.Windows.Media.Brushes.Green : System.Windows.Media.Brushes.Red;
            }
        }

        private Label GetRoomLabel(int roomNumber)
        {
            switch (roomNumber)
            {
                case 101: return room101;
                case 102: return room102;
                case 103: return room103;
                case 104: return room104;
                case 201: return room201;
                case 202: return room202;
                case 203: return room203;
                case 204: return room204;
                case 301: return room301;
                case 302: return room302;
                case 303: return room303;
                case 304: return room304;
                case 401: return room401;
                case 402: return room402;
                case 403: return room403;
                case 404: return room404;
                default: return null;
            }
        }
       
    }

}
