﻿using System.Data;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace Reservation_hotel.Chambre
{
    public partial class ModifierCHAMBRE : Window
    {
        string connectionString = "Server=DESKTOP-2K5N25U\\SQLEXPRESS;Database=HotelDb;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;";
        public ModifierCHAMBRE()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ChargerChambres();
            ChargerTypesChambres();
        }
        private void ChargerChambres()
        {
            try
            {
                string query = @"SELECT c.Id, c.NumeroChambre, c.Disponibilite, c.TypeChambreId, t.typeChambre FROM Chambres c JOIN Type_Chambres t ON c.TypeChambreId = t.id";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);
                    dgvChambre.ItemsSource = dataTable.DefaultView;
                    var typeChambreIdColumn = dgvChambre.Columns
                                                          .FirstOrDefault(c => c.Header.ToString() == "TypeChambreId");
                    if (typeChambreIdColumn != null)
                    {
                        typeChambreIdColumn.Visibility = System.Windows.Visibility.Collapsed;
                    }

                    Console.WriteLine($"Données chargées : {dataTable.Rows.Count} lignes.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Une erreur est survenue : " + ex.Message);
            }
        }


        private void ChargerTypesChambres()
        {
            try
            {
                string query = "SELECT id, typeChambre FROM Type_Chambres";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);
                    comboboxType.DisplayMemberPath = "typeChambre";
                    comboboxType.SelectedValuePath = "id";
                    comboboxType.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Une erreur est survenue lors du chargement des types de chambres : " + ex.Message);
            }
        }
        private void dgvChambre_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (dgvChambre.SelectedItem != null)
            {
                try
                {
                    DataRowView selectedRow = (DataRowView)dgvChambre.SelectedItem;
                    if (selectedRow["NumeroChambre"] != DBNull.Value)
                    {
                        txtnumChambre.Text = selectedRow["NumeroChambre"].ToString();
                    }
                    else
                    {
                        txtnumChambre.Text = string.Empty;
                    }
                    if (selectedRow["TypeChambreId"] != DBNull.Value)
                    {
                        int typeChambreId = (int)selectedRow["TypeChambreId"];
                        comboboxType.SelectedValue = typeChambreId;
                    }
                    else
                    {
                        comboboxType.SelectedValue = null;
                    }
                    btnModifierChambre.IsEnabled = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de la sélection de la chambre : " + ex.Message);
                }
            }
        }
        private void btnModifierChambre_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int numeroChambre = int.Parse(txtnumChambre.Text);
                int typeChambreId = (int)comboboxType.SelectedValue;
                DataRowView selectedRow = (DataRowView)dgvChambre.SelectedItem;
                int chambreId = (int)selectedRow["Id"];
                string query = @"UPDATE Chambres SET NumeroChambre = @NumeroChambre, TypeChambreId = @TypeChambreId WHERE Id = @Id";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@NumeroChambre", numeroChambre);
                    command.Parameters.AddWithValue("@TypeChambreId", typeChambreId);
                    command.Parameters.AddWithValue("@Id", chambreId);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
                ChargerChambres();
                MessageBox.Show("Chambre modifiée avec succès.");
                txtnumChambre.Text = string.Empty;
                comboboxType.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Une erreur est survenue lors de la modification : " + ex.Message);
            }
        }
        private void dgv_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            // Set the width of each column to fill the DataGrid
            e.Column.Width = new DataGridLength(1, DataGridLengthUnitType.Star);
        }

    }
}
