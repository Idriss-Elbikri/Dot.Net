﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Navigation;

namespace Reservation_hotel
{
    public partial class EMP : Window
    {
        public EMP()
        {
            InitializeComponent();
        }



        private void btn_Logout_Click(object sender, RoutedEventArgs e)
        {
            // Open the MainWindow
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();

            // Close the current Admin window
            this.Close();
        }

        //reservation
        private void btn_RES_Click(object sender, RoutedEventArgs e)
        {

            MainGrid.Children.Clear();
            MainGrid.RowDefinitions.Clear();


            for (int i = 0; i < 2; i++)
            {
                MainGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition());
            }


            var buttonLister = new System.Windows.Controls.Button
            {
                Content = "Lister Reservations",
                HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
                VerticalAlignment = System.Windows.VerticalAlignment.Top,
                Margin = new System.Windows.Thickness(30, 30, 0, 0),
                Width = 250,
                Height = 150,
                FontSize = 24
            };
            Grid.SetRow(buttonLister, 0);
            buttonLister.Click += btn_ListerRES_Click;
            MainGrid.Children.Add(buttonLister);

            var buttonAjouter = new System.Windows.Controls.Button
            {
                Content = "Ajouter Reservations",
                HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
                VerticalAlignment = System.Windows.VerticalAlignment.Top,
                Margin = new System.Windows.Thickness(0, 30, 30, 0),
                Width = 250,
                Height = 150,
                FontSize = 24
            };
            Grid.SetRow(buttonAjouter, 0);
            buttonAjouter.Click += btn_AjouterRES_Click;
            MainGrid.Children.Add(buttonAjouter);

            var buttonModifier = new System.Windows.Controls.Button
            {
                Content = "Modifier Reservations",
                HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
                VerticalAlignment = System.Windows.VerticalAlignment.Top,
                Margin = new System.Windows.Thickness(30, 30, 0, 0),
                Width = 250,
                Height = 150,
                FontSize = 24
            };
            Grid.SetRow(buttonModifier, 1);
            buttonModifier.Click += btn_ModifierRES_Click;
            MainGrid.Children.Add(buttonModifier);
        }

        private void btn_AjouterRES_Click(object sender, RoutedEventArgs e)
        {

            Reservation.AjouterRES ajouterRES = new Reservation.AjouterRES();
            ajouterRES.Show();

        }

        private void btn_ListerRES_Click(object sender, RoutedEventArgs e)
        {

            Reservation.ListerRes listerRES = new Reservation.ListerRes();
            listerRES.Show();

        }

        private void btn_ModifierRES_Click(object sender, RoutedEventArgs e)
        {

            Reservation.ModifierRES modifierRES = new Reservation.ModifierRES();
            modifierRES.Show();

        }

        //chambre

        private void btn_CHAMBRE_Click(object sender, RoutedEventArgs e)
        {
            MainGrid.Children.Clear();
            MainGrid.RowDefinitions.Clear();
            for (int i = 0; i < 2; i++)
            {
                MainGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition());
            }


            var buttonLister = new System.Windows.Controls.Button
            {
                Content = "Lister Chambres",
                HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
                VerticalAlignment = System.Windows.VerticalAlignment.Top,
                Margin = new System.Windows.Thickness(30, 30, 0, 0),
                Width = 250,
                Height = 150,
                FontSize = 24
            };
            Grid.SetRow(buttonLister, 0);
            buttonLister.Click += btn_ListerCHAMBRE_Click;
            MainGrid.Children.Add(buttonLister);

            var buttonModifier = new System.Windows.Controls.Button
            {
                Content = "Modifier Chambres",
                HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
                VerticalAlignment = System.Windows.VerticalAlignment.Top,
                Margin = new System.Windows.Thickness(30, 30, 0, 0),
                Width = 250,
                Height = 150,
                FontSize = 24
            };
            Grid.SetRow(buttonModifier, 1);
            buttonModifier.Click += btn_ModifierCHAMBRE_Click;
            MainGrid.Children.Add(buttonModifier);
        }

        private void btn_ListerCHAMBRE_Click(object sender, RoutedEventArgs e)
        {

            Chambre.AjouterCHAMBRE listerCHAMBRE = new Chambre.AjouterCHAMBRE();
            listerCHAMBRE.Show();

        }

        private void btn_ModifierCHAMBRE_Click(object sender, RoutedEventArgs e)
        {

            Chambre.ModifierCHAMBRE modifierCHAMBRE = new Chambre.ModifierCHAMBRE();
            modifierCHAMBRE.Show();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // Clear the MainGrid content
            MainGrid.Children.Clear();
            MainGrid.RowDefinitions.Clear();

            // Add default elements to MainGrid (background and logo)
            var background = new Image
            {
                Source = new System.Windows.Media.Imaging.BitmapImage(new System.Uri("C:\\Users\\pc\\OneDrive\\Bureau\\Documents\\Projets\\C#\\Final\\DESKTOP\\Reservation hotel Desktop\\Reservation hotel\\Images\\Background\\Bc2.jpg")),
                Stretch = Stretch.UniformToFill,
                Opacity = 0.8
            };
            var blurEffect = new System.Windows.Media.Effects.BlurEffect { Radius = 1 };
            background.Effect = blurEffect;
            MainGrid.Children.Add(background);

            var logo = new Image
            {
                Source = new System.Windows.Media.Imaging.BitmapImage(new System.Uri("C:\\Users\\pc\\OneDrive\\Bureau\\Documents\\Projets\\C#\\Final\\DESKTOP\\Reservation hotel Desktop\\Reservation hotel\\Images\\Logo\\Hotel2.png")),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Height = 333,
                Width = 452
            };
            MainGrid.Children.Add(logo);
        }
    }
}
