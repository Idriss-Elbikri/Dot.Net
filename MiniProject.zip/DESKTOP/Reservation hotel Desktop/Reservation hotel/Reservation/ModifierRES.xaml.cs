﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace Reservation_hotel.Reservation
{
    // Classe pour représenter une chambre
    public class Chambre
    {
        public int Id { get; set; }
        public string Numero { get; set; }
    }

    public partial class ModifierRES : Window
    {
        string connectionString = "Server=DESKTOP-2K5N25U\\SQLEXPRESS;Database=HotelDb;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;";
        int selectedReservationId = -1; // ID de la réservation sélectionnée
        int oldChambreId = -1; // Stocke l'ancienne chambre sélectionnée

        public ModifierRES()
        {
            InitializeComponent();
        }

        // Chargement initial de la fenêtre
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ConfigurerDataGrid();  // Configure la DataGrid
            ChargerReservations(); // Charge les réservations existantes
        }

        // Configurer les colonnes de la DataGrid
        private void ConfigurerDataGrid()
        {
            dgvReservations.AutoGenerateColumns = false;

            // Ajouter les colonnes manuellement
            dgvReservations.Columns.Add(new DataGridTextColumn { Header = "Nom", Binding = new System.Windows.Data.Binding("Nom") });
            dgvReservations.Columns.Add(new DataGridTextColumn { Header = "Prenom", Binding = new System.Windows.Data.Binding("Prenom") });
            dgvReservations.Columns.Add(new DataGridTextColumn { Header = "CIN", Binding = new System.Windows.Data.Binding("Cin") });
            dgvReservations.Columns.Add(new DataGridTextColumn { Header = "Téléphone", Binding = new System.Windows.Data.Binding("Telephone") });
            dgvReservations.Columns.Add(new DataGridTextColumn { Header = "Date Début", Binding = new System.Windows.Data.Binding("DateDebut") });
            dgvReservations.Columns.Add(new DataGridTextColumn { Header = "Date Fin", Binding = new System.Windows.Data.Binding("DateFin") });

            // Masquer la colonne ChambreId
            dgvReservations.Columns.Add(new DataGridTextColumn
            {
                Header = "ChambreId",
                Binding = new System.Windows.Data.Binding("ChambreId"),
                Visibility = Visibility.Collapsed
            });

            // Afficher uniquement le numéro de chambre
            dgvReservations.Columns.Add(new DataGridTextColumn
            {
                Header = "Numéro Chambre",
                Binding = new System.Windows.Data.Binding("NumeroChambre")
            });
        }

        // Charger les réservations dans la DataGrid
        private void ChargerReservations(string searchQuery = "")
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = @"
                SELECT 
                    R.Id, -- Ajout de la colonne Id
                    COALESCE(RT.Nom, C.Nom) AS Nom,
                    COALESCE(RT.Prenom, C.Prenom) AS Prenom,
                    COALESCE(RT.Cin, C.Cin) AS Cin,
                    COALESCE(RT.Telephone, C.Telephone) AS Telephone,
                    CONVERT(varchar, R.DateDebut, 23) AS DateDebut, 
                    CONVERT(varchar, R.DateFin, 23) AS DateFin,
                    Ch.Id AS ChambreId, -- Ajout de la colonne ChambreId
                    Ch.NumeroChambre AS NumeroChambre -- Correction du nom de la colonne
                FROM Reservation R
                LEFT JOIN Reservation_Temporaire RT ON R.ReservationTemporaireId = RT.Id
                LEFT JOIN Client C ON R.ClientId = C.Id
                INNER JOIN Chambres Ch ON R.ChambreId = Ch.Id
                WHERE 
                    (RT.Nom LIKE @search OR
                    RT.Prenom LIKE @search OR
                    RT.Cin LIKE @search OR
                    RT.Telephone LIKE @search OR
                    C.Nom LIKE @search OR
                    C.Prenom LIKE @search OR
                    C.Cin LIKE @search OR
                    C.Telephone LIKE @search)";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@search", $"%{searchQuery}%");

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dgvReservations.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des réservations : " + ex.Message);
            }
        }

        // Charger uniquement les chambres disponibles + la chambre actuelle
        private void ChargerChambres(int? chambreActuelleId = null)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    // Inclure la chambre actuelle (réservée) et les chambres disponibles
                    string query = @"
                        SELECT Id, NumeroChambre 
                        FROM Chambres
                        WHERE Disponibilite = 1 OR Id = @ChambreActuelleId";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@ChambreActuelleId", chambreActuelleId.HasValue ? chambreActuelleId.Value : (object)DBNull.Value);

                    SqlDataReader reader = cmd.ExecuteReader();
                    cmbChambres.Items.Clear();

                    while (reader.Read())
                    {
                        cmbChambres.Items.Add(new Chambre
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Numero = reader["NumeroChambre"].ToString()
                        });
                    }

                    cmbChambres.DisplayMemberPath = "Numero";
                    cmbChambres.SelectedValuePath = "Id";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des chambres : " + ex.Message);
            }
        }

        // Remplir les champs lors de la sélection dans la DataGrid
        private void dgvReservations_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgvReservations.SelectedItem != null)
            {
                DataRowView row = (DataRowView)dgvReservations.SelectedItem;
                selectedReservationId = Convert.ToInt32(row["Id"]);
                txtNom.Text = row["Nom"].ToString();
                txtPrenom.Text = row["Prenom"].ToString();
                txtCIN.Text = row["Cin"].ToString();
                txtTelephone.Text = row["Telephone"].ToString();
                dpDateDebut.SelectedDate = DateTime.Parse(row["DateDebut"].ToString());
                dpDateFin.SelectedDate = DateTime.Parse(row["DateFin"].ToString());

                // Charger la chambre actuelle
                oldChambreId = Convert.ToInt32(row["ChambreId"]);
                ChargerChambres(oldChambreId); // Inclure la chambre actuelle dans la liste
                cmbChambres.SelectedValue = oldChambreId; // Sélectionner la chambre actuelle
            }
        }

        // Modifier la réservation sélectionnée
        private void Modifier_Click(object sender, RoutedEventArgs e)
        {
            if (selectedReservationId == -1 || cmbChambres.SelectedIndex == -1)
            {
                MessageBox.Show("Veuillez sélectionner une réservation et une chambre !");
                return;
            }

            if (dpDateDebut.SelectedDate >= dpDateFin.SelectedDate)
            {
                MessageBox.Show("La date de début doit être antérieure à la date de fin !");
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    // Libérer l'ancienne chambre si différente
                    if (oldChambreId != (int)cmbChambres.SelectedValue)
                    {
                        SqlCommand cmdLiberer = new SqlCommand("UPDATE Chambres SET Disponibilite = 1 WHERE Id = @ChambreId", con);
                        cmdLiberer.Parameters.AddWithValue("@ChambreId", oldChambreId);
                        cmdLiberer.ExecuteNonQuery();

                        SqlCommand cmdReserver = new SqlCommand("UPDATE Chambres SET Disponibilite = 0 WHERE Id = @ChambreId", con);
                        cmdReserver.Parameters.AddWithValue("@ChambreId", cmbChambres.SelectedValue);
                        cmdReserver.ExecuteNonQuery();
                    }

                    SqlCommand cmd = new SqlCommand(@"
                        UPDATE Reservation
                        SET DateDebut = @DateDebut, DateFin = @DateFin, ChambreId = @ChambreId
                        WHERE Id = @Id", con);
                    cmd.Parameters.AddWithValue("@Id", selectedReservationId);
                    cmd.Parameters.AddWithValue("@DateDebut", dpDateDebut.SelectedDate.Value);
                    cmd.Parameters.AddWithValue("@DateFin", dpDateFin.SelectedDate.Value);
                    cmd.Parameters.AddWithValue("@ChambreId", cmbChambres.SelectedValue);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Modification réussie !");
                    ChargerReservations();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message);
            }
        }

        private void dgv_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            // Set the width of each column to fill the DataGrid
            e.Column.Width = new DataGridLength(1, DataGridLengthUnitType.Star);
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string searchQuery = txtSearch.Text; // Get the search input from the TextBox
            ChargerReservations(searchQuery);   // Pass the search query to the ChargerReservations method
        }
    }
}