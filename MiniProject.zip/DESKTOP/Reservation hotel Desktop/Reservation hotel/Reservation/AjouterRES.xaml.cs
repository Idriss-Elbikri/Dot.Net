﻿using System;
using System.Windows;
using Microsoft.Data.SqlClient;

namespace Reservation_hotel.Reservation
{
    public partial class AjouterRES : Window
    {
        // Chaîne de connexion à la base de données
        string connectionString = "Server=DESKTOP-2K5N25U\\SQLEXPRESS;Database=HotelDb;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;";

        public AjouterRES()
        {
            InitializeComponent();
            ChargerChambresDisponibles(); // Charge les chambres disponibles au démarrage
        }

        // Méthode pour charger les chambres disponibles
        private void ChargerChambresDisponibles()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "SELECT Id, NumeroChambre FROM Chambres WHERE Disponibilite = 1";
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        cmbChambres.Items.Add(new
                        {
                            Id = reader["Id"],
                            Numero = reader["NumeroChambre"].ToString()
                        });
                    }

                    cmbChambres.DisplayMemberPath = "Numero";
                    cmbChambres.SelectedValuePath = "Id";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors du chargement des chambres : " + ex.Message);
                }
            }
        }

        // Méthode pour ajouter une réservation
        private void btnajout_Click(object sender, RoutedEventArgs e)
        {
            // Récupérer les données des champs
            string nom = txtnom.Text;
            string prenom = txtprenom.Text;
            string telephone = txttel.Text;
            string cin = txtcin.Text;
            DateTime? dateArrivee = txtdate_arrivee.SelectedDate;
            DateTime? dateFin = txtdate_Fin.SelectedDate;

            // Validation des champs requis
            if (string.IsNullOrWhiteSpace(nom) || string.IsNullOrWhiteSpace(prenom) ||
                string.IsNullOrWhiteSpace(telephone) || string.IsNullOrWhiteSpace(cin) ||
                dateArrivee == null || dateFin == null)
            {
                MessageBox.Show("Veuillez remplir tous les champs.");
                return;
            }

            // Validation des dates
            if (dateFin <= dateArrivee)
            {
                MessageBox.Show("La date de fin doit être postérieure à la date d'arrivée.");
                return;
            }

            // Validation de la chambre sélectionnée
            if (cmbChambres.SelectedValue == null)
            {
                MessageBox.Show("Veuillez sélectionner une chambre.");
                return;
            }

            int chambreId = (int)cmbChambres.SelectedValue;

            // Connexion et insertion dans la base de données
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();

                    // Insérer dans la table temporaire
                    string insertTemporaireQuery = @"
                        INSERT INTO Reservation_Temporaire (Nom, Prenom, Cin, Telephone, TypeReservation)
                        OUTPUT INSERTED.Id
                        VALUES (@Nom, @Prenom, @Cin, @Telephone, @TypeReservation)";

                    SqlCommand cmdTemporaire = new SqlCommand(insertTemporaireQuery, con);
                    cmdTemporaire.Parameters.AddWithValue("@Nom", nom);
                    cmdTemporaire.Parameters.AddWithValue("@Prenom", prenom);
                    cmdTemporaire.Parameters.AddWithValue("@Cin", cin);
                    cmdTemporaire.Parameters.AddWithValue("@Telephone", telephone);
                    cmdTemporaire.Parameters.AddWithValue("@TypeReservation", "Normal");

                    int reservationTemporaireId = (int)cmdTemporaire.ExecuteScalar();

                    // Insérer dans la table principale des réservations
                    string insertReservationQuery = @"
                        INSERT INTO Reservation (DateDebut, DateFin, ChambreId, ReservationTemporaireId)
                        VALUES (@DateDebut, @DateFin, @ChambreId, @ReservationTemporaireId)";

                    SqlCommand cmdReservation = new SqlCommand(insertReservationQuery, con);
                    cmdReservation.Parameters.AddWithValue("@DateDebut", dateArrivee.Value);
                    cmdReservation.Parameters.AddWithValue("@DateFin", dateFin.Value);
                    cmdReservation.Parameters.AddWithValue("@ChambreId", chambreId);
                    cmdReservation.Parameters.AddWithValue("@ReservationTemporaireId", reservationTemporaireId);

                    int rowsAffected = cmdReservation.ExecuteNonQuery();

                    // Mettre à jour la disponibilité de la chambre
                    string updateChambreQuery = "UPDATE Chambres SET Disponibilite = 0 WHERE Id = @ChambreId";
                    SqlCommand cmdUpdateChambre = new SqlCommand(updateChambreQuery, con);
                    cmdUpdateChambre.Parameters.AddWithValue("@ChambreId", chambreId);
                    cmdUpdateChambre.ExecuteNonQuery();

                    // Vérification de l'insertion
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Réservation ajoutée avec succès !");
                        // Réinitialiser les champs après l'ajout
                        txtnom.Text = string.Empty;
                        txtprenom.Text = string.Empty;
                        txttel.Text = string.Empty;
                        txtcin.Text = string.Empty;
                        txtdate_arrivee.SelectedDate = null;
                        txtdate_Fin.SelectedDate = null;
                        cmbChambres.SelectedIndex = -1;
                    }
                    else
                    {
                        MessageBox.Show("Échec de l'ajout de la réservation.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Une erreur est survenue : " + ex.Message);
                }
            }
        }
    }
}
