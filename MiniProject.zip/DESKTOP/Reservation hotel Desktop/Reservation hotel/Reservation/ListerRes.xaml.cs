﻿using System;
using System.Data;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.Data.SqlClient;
using Microsoft.Win32; // Pour le dialogue de sélection de fichier
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Kernel.Font;
using iText.IO.Font.Constants;

namespace Reservation_hotel.Reservation
{
    public partial class ListerRes : Window
    {
        // Chaîne de connexion à la base de données
        string connectionString = "Server=DESKTOP-2K5N25U\\SQLEXPRESS;Database=HotelDb;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;";

        public ListerRes()
        {
            InitializeComponent();
        }

        // Chargement initial des données dans le DataGrid
        private void dgvResliste_Loaded(object sender, RoutedEventArgs e)
        {
            ChargerReservations(); // Charge toutes les réservations au démarrage
        }

        // Méthode pour charger les données avec ou sans filtre
        private void ChargerReservations(string searchQuery = "")
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = @"
                                    SELECT 
                                        COALESCE(RT.Nom, C.Nom) AS Nom,
                                        COALESCE(RT.Prenom, C.Prenom) AS Prenom,
                                        COALESCE(RT.Cin, C.Cin) AS Cin,
                                        COALESCE(RT.Telephone, C.Telephone) AS Telephone,
                                        CONVERT(varchar, R.DateDebut, 23) AS DateDebut, 
                                        CONVERT(varchar, R.DateFin, 23) AS DateFin,
                                        Ch.NumeroChambre
                                    FROM Reservation R
                                    LEFT JOIN Reservation_Temporaire RT ON R.ReservationTemporaireId = RT.Id
                                    LEFT JOIN Client C ON R.ClientId = C.Id
                                    INNER JOIN Chambres Ch ON R.ChambreId = Ch.Id
                                    WHERE 
                                        (RT.Nom LIKE @search OR
                                        RT.Prenom LIKE @search OR
                                        RT.Cin LIKE @search OR
                                        RT.Telephone LIKE @search OR
                                        C.Nom LIKE @search OR
                                        C.Prenom LIKE @search OR
                                        C.Cin LIKE @search OR
                                        C.Telephone LIKE @search)";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@search", $"%{searchQuery}%");

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dgvResliste.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des réservations : " + ex.Message);
            }
        }

        private void txtsearchRes_TextChanged(object sender, TextChangedEventArgs e)
        {
            ChargerReservations(txtsearchRes.Text.Trim());
        }

        // Suppression d'une réservation sélectionnée
        private void DeleteRes_Click(object sender, RoutedEventArgs e)
        {
            if (dgvResliste.SelectedItem != null)
            {
                DataRowView row = (DataRowView)dgvResliste.SelectedItem;
                string cin = row["Cin"].ToString();
                DateTime dateDebut = Convert.ToDateTime(row["DateDebut"]);
                DateTime dateFin = Convert.ToDateTime(row["DateFin"]);
                string chambre = row["NumeroChambre"].ToString();

                try
                {
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        con.Open();

                        // Supprimer la réservation
                        string deleteQuery = @"
                            DELETE FROM Reservation
                            WHERE ReservationTemporaireId IN (
                                SELECT Id FROM Reservation_Temporaire WHERE Cin = @Cin
                            ) AND DateDebut = @DateDebut AND DateFin = @DateFin";

                        SqlCommand cmdDelete = new SqlCommand(deleteQuery, con);
                        cmdDelete.Parameters.AddWithValue("@Cin", cin);
                        cmdDelete.Parameters.AddWithValue("@DateDebut", dateDebut);
                        cmdDelete.Parameters.AddWithValue("@DateFin", dateFin);
                        cmdDelete.ExecuteNonQuery();

                        // Mettre à jour la disponibilité de la chambre
                        string updateQuery = "UPDATE Chambres SET Disponibilite = 1 WHERE NumeroChambre = @Chambre";
                        SqlCommand cmdUpdate = new SqlCommand(updateQuery, con);
                        cmdUpdate.Parameters.AddWithValue("@Chambre", chambre);
                        cmdUpdate.ExecuteNonQuery();

                        MessageBox.Show("Réservation supprimée avec succès !");
                        ChargerReservations(); // Recharge les données après suppression
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de la suppression : " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner une réservation à supprimer.");
            }
        }

        // Export vers Excel
        private void btnExport_Click(object sender, RoutedEventArgs e)
        {
            if (dgvResliste.Items.Count > 0)
            {
                try
                {
                    dgvResliste.SelectAll();
                    ApplicationCommands.Copy.Execute(null, dgvResliste);
                    string data = (string)Clipboard.GetData(DataFormats.Text);

                    SaveFileDialog saveFileDialog = new SaveFileDialog
                    {
                        Filter = "Excel Files (*.xls)|*.xls",
                        FileName = $"ReservationsExport_{DateTime.Now:yyyyMMddHHmmss}.xls"
                    };

                    if (saveFileDialog.ShowDialog() == true)
                    {
                        File.WriteAllText(saveFileDialog.FileName, data);
                        MessageBox.Show("Exportation Excel réussie !");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erreur lors de l'exportation vers Excel : {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Aucune donnée à exporter !");
            }
        }

        // Export PDF
        private void btnExportPDF_Click(object sender, RoutedEventArgs e)
        {
            if (dgvResliste.SelectedItem != null)
            {
                DataRowView row = (DataRowView)dgvResliste.SelectedItem;

                string nom = row["Nom"].ToString();
                string prenom = row["Prenom"].ToString();
                string telephone = row["Telephone"].ToString();
                string cin = row["Cin"].ToString();
                DateTime dateArrivee = DateTime.Parse(row["DateDebut"].ToString());
                DateTime dateFin = DateTime.Parse(row["DateFin"].ToString());
                string chambre = row["NumeroChambre"].ToString();

                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "PDF Files (*.pdf)|*.pdf",
                    FileName = $"Facture_{nom}_{prenom}_{DateTime.Now:yyyyMMddHHmmss}.pdf"
                };

                if (saveFileDialog.ShowDialog() == true)
                {
                    try
                    {
                        using (FileStream fs = new FileStream(saveFileDialog.FileName, FileMode.Create, FileAccess.Write))
                        using (PdfWriter writer = new PdfWriter(fs))
                        using (PdfDocument pdf = new PdfDocument(writer))
                        using (Document document = new Document(pdf))
                        {
                            document.Add(new Paragraph("FACTURE DE RESERVATION")
                                .SetTextAlignment(iText.Layout.Properties.TextAlignment.CENTER)
                                .SetFontSize(20)
                                .SetFont(PdfFontFactory.CreateFont(StandardFonts.HELVETICA_BOLD)));

                            document.Add(new Paragraph($"Nom : {nom}"));
                            document.Add(new Paragraph($"Prénom : {prenom}"));
                            document.Add(new Paragraph($"Téléphone : {telephone}"));
                            document.Add(new Paragraph($"CIN : {cin}\n"));

                            document.Add(new Paragraph($"Chambre : {chambre}"));
                            document.Add(new Paragraph($"Date d'arrivée : {dateArrivee:dd/MM/yyyy}"));
                            document.Add(new Paragraph($"Date de départ : {dateFin:dd/MM/yyyy}"));
                        }

                        MessageBox.Show("Facture exportée avec succès !");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Erreur PDF : {ex.Message}");
                    }
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner une réservation à exporter.");
            }
        }

        private void dgv_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            // Set the width of each column to fill the DataGrid
            e.Column.Width = new DataGridLength(1, DataGridLengthUnitType.Star);
        }

    }
}
