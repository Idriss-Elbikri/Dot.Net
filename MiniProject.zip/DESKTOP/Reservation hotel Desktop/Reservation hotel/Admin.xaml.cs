﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Windows.Input;
using System.Windows.Media;

namespace Reservation_hotel
{
    public partial class Admin : Window
    {
        string connectionString = "Server=DESKTOP-2K5N25U\\SQLEXPRESS;Database=HotelDb;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;";
        public Admin()
        {
            InitializeComponent();
        }

        private void btn_Admin_Click(object sender, RoutedEventArgs e)
        {
            // Clear the MainGrid content
            MainGrid.Children.Clear();
            MainGrid.RowDefinitions.Clear();

            // Add default elements to MainGrid (background and logo)
            var background = new Image
            {
                Source = new System.Windows.Media.Imaging.BitmapImage(new System.Uri("C:\\Users\\pc\\OneDrive\\Bureau\\Documents\\Projets\\C#\\Final\\DESKTOP\\Reservation hotel Desktop\\Reservation hotel\\Images\\Background\\Bc2.jpg")),
                Stretch = Stretch.UniformToFill,
                Opacity = 0.8
            };
            var blurEffect = new System.Windows.Media.Effects.BlurEffect { Radius = 1 };
            background.Effect = blurEffect;
            MainGrid.Children.Add(background);

            var logo = new Image
            {
                Source = new System.Windows.Media.Imaging.BitmapImage(new System.Uri("C:\\Users\\pc\\OneDrive\\Bureau\\Documents\\Projets\\C#\\Final\\DESKTOP\\Reservation hotel Desktop\\Reservation hotel\\Images\\Logo\\Hotel2.png")),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Height = 333,
                Width = 452
            };
            MainGrid.Children.Add(logo);
        }

        private void btn_Logout_Click(object sender, RoutedEventArgs e)
        {
            // Open the MainWindow
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();

            // Close the current Admin window
            this.Close();
        }


        //Employe
        private void btn_EMP_Click(object sender, RoutedEventArgs e)
        {
            MainGrid.Children.Clear();
            MainGrid.RowDefinitions.Clear();
            for (int i = 0; i < 2; i++)
            {
                MainGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition());
            }
            var buttonLister = new System.Windows.Controls.Button
            {
                Content = "Lister Employes",
                HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
                VerticalAlignment = System.Windows.VerticalAlignment.Top,
                Margin = new System.Windows.Thickness(30, 30, 0, 0),
                Width = 250,
                Height = 150,
                FontSize = 24
            };
            Grid.SetRow(buttonLister, 0);
            buttonLister.Click += btn_ListerEMP_Click;
            MainGrid.Children.Add(buttonLister);

            var buttonAjouter = new System.Windows.Controls.Button
            {
                Content = "Ajouter Employes",
                HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
                VerticalAlignment = System.Windows.VerticalAlignment.Top,
                Margin = new System.Windows.Thickness(0, 30, 30, 0),
                Width = 250,
                Height = 150,
                FontSize = 24,
            };
            Grid.SetRow(buttonAjouter, 0);
            buttonAjouter.Click += btn_AjouterEMP_Click;
            MainGrid.Children.Add(buttonAjouter);

            var buttonModifier = new System.Windows.Controls.Button
            {
                Content = "Modifier Employes",
                HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                VerticalAlignment = System.Windows.VerticalAlignment.Top,
                Margin = new System.Windows.Thickness(30, 30, 0, 0),
                Width = 250,
                Height = 150,
                FontSize = 24
            };
            Grid.SetRow(buttonModifier, 1);
            buttonModifier.Click += btn_ModifierEMP_Click;
            MainGrid.Children.Add(buttonModifier);
        }
        private void btn_AjouterEMP_Click(object sender, RoutedEventArgs e)
        {
            Employe.AjouterEMP ajouterEMP = new Employe.AjouterEMP();
            ajouterEMP.Show();
        }
        private void btn_ModifierEMP_Click(object sender, RoutedEventArgs e)
        {
            Employe.ModifierEMP modifierEMP = new Employe.ModifierEMP();
            modifierEMP.Show();
        }
        private void btn_ListerEMP_Click(object sender, RoutedEventArgs e)
        {
            Employe.ListerEMP listerEMP = new Employe.ListerEMP();
            listerEMP.Show();
        }

        //Client

        // Variable pour stocker la DataGrid
        private DataGrid gridListeCLT;

        // Variable pour stocker la TextBox de recherche
        private TextBox txtSearchCLT;


        private void btn_CLT_Click(object sender, RoutedEventArgs e)
        {
            // Vider les éléments actuels dans MainGrid
            MainGrid.Children.Clear();
            MainGrid.RowDefinitions.Clear();

            // Ajouter des lignes pour organiser les éléments
            MainGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            MainGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // Ajouter un bouton d'exportation
            var btnExportCLT = new Button
            {
                Name = "btnExportCLT",
                Content = "Export",
                Margin = new Thickness(0, 60, 0, 0),
                Height = 30,
                Width = 60,
                FontSize = 16,
                VerticalAlignment = VerticalAlignment.Top,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            btnExportCLT.Click += btnExport_Click;
            MainGrid.Children.Add(btnExportCLT);
            Grid.SetRow(btnExportCLT, 0);

            // Ajouter un champ de recherche
            txtSearchCLT = new TextBox
            {
                Name = "txtSearchCLT",
                Margin = new Thickness(20),
                Height = 30,
                FontSize = 16,
                VerticalAlignment = VerticalAlignment.Top,
                HorizontalAlignment = HorizontalAlignment.Stretch
            };
            MainGrid.Children.Add(txtSearchCLT);
            Grid.SetRow(txtSearchCLT, 0);

            // Ajouter une DataGrid pour afficher la liste des clients
            gridListeCLT = new DataGrid
            {
                Name = "gridListeCLT",
                Margin = new Thickness(20),
                AutoGenerateColumns = true,
                CanUserAddRows = false,
                IsReadOnly = true,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Stretch,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto
            };
            MainGrid.Children.Add(gridListeCLT);
            Grid.SetRow(gridListeCLT, 1);

            gridListeCLT.AutoGeneratingColumn += (s, e) =>
            {
                e.Column.Width = new DataGridLength(1, DataGridLengthUnitType.Star);
            };

            // Charger les données des clients
            LoadClients(gridListeCLT, txtSearchCLT);
        }


        private void btnExport_Click(object sender, RoutedEventArgs e)
        {
            // Vérifie si la DataGrid contient des éléments
            if (gridListeCLT.Items.Count == 0)
            {
                MessageBox.Show("No data available to export!", "Export Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Sélectionner toutes les lignes
            gridListeCLT.SelectAll();
            ApplicationCommands.Copy.Execute(null, gridListeCLT);

            // Récupérer les données copiées dans le presse-papiers
            string clipboardData = (string)Clipboard.GetData(DataFormats.Text);
            if (!string.IsNullOrEmpty(clipboardData))
            {
                // Initialiser Excel
                Microsoft.Office.Interop.Excel.Application xlapp = new Microsoft.Office.Interop.Excel.Application();
                xlapp.Visible = true;
                Microsoft.Office.Interop.Excel.Workbook xlWbook = xlapp.Workbooks.Add();
                Microsoft.Office.Interop.Excel.Worksheet xlsheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWbook.Worksheets[1];

                // Ajouter les en-têtes
                for (int j = 0; j < gridListeCLT.Columns.Count; j++)
                {
                    xlsheet.Cells[1, j + 1] = gridListeCLT.Columns[j].Header.ToString(); // Récupère les noms des colonnes
                }

                // Ajouter les données
                string[] rows = clipboardData.Split('\n'); // Séparer les lignes
                for (int i = 0; i < rows.Length; i++)
                {
                    string[] cells = rows[i].Split('\t'); // Séparer les colonnes
                    for (int j = 0; j < cells.Length; j++)
                    {
                        xlsheet.Cells[i + 2, j + 1] = cells[j]; // Ajouter les données sous les en-têtes
                    }
                }

                // Ajuster automatiquement la largeur des colonnes
                xlsheet.Columns.AutoFit();
            }
            else
            {
                MessageBox.Show("No data to export!", "Export Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }



        // Méthode pour charger les données dans la DataGrid
        private void LoadClients(DataGrid grid, TextBox searchBox)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT Id, Nom, Prenom, Cin, Telephone, Email FROM Client";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    grid.ItemsSource = dt.DefaultView;

                    // Ajouter un filtre sur la recherche
                    searchBox.TextChanged += (s, e) =>
                    {
                        string filter = searchBox.Text.Trim();
                        if (!string.IsNullOrEmpty(filter))
                        {
                            DataView dv = dt.DefaultView;
                            dv.RowFilter = $"Nom LIKE '%{filter}%' OR Prenom LIKE '%{filter}%' OR Email LIKE '%{filter}%'";
                            grid.ItemsSource = dv;
                        }
                        else
                        {
                            grid.ItemsSource = dt.DefaultView;
                        }
                    };
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message, "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        //Reservation
        private void btn_RES_Click(object sender, RoutedEventArgs e)
        {
            MainGrid.Children.Clear();
            MainGrid.RowDefinitions.Clear();
            for (int i = 0; i < 2; i++)
            {
                MainGrid.RowDefinitions.Add(new System.Windows.Controls.RowDefinition());
            }
            var buttonLister = new System.Windows.Controls.Button
            {
                Content = "Lister Reservation",
                HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
                VerticalAlignment = System.Windows.VerticalAlignment.Top,
                Margin = new System.Windows.Thickness(30, 30, 0, 0),
                Width = 250,
                Height = 150,
                FontSize = 24
            };
            Grid.SetRow(buttonLister, 0);
            buttonLister.Click += btn_ListerRes_Click;
            MainGrid.Children.Add(buttonLister);

            var buttonAjouter = new System.Windows.Controls.Button
            {
                Content = "Ajouter Reservation",
                HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
                VerticalAlignment = System.Windows.VerticalAlignment.Top,
                Margin = new System.Windows.Thickness(0, 30, 30, 0),
                Width = 250,
                Height = 150,
                FontSize = 24
            };
            Grid.SetRow(buttonAjouter, 0);
            buttonAjouter.Click += btn_AjouterRES_Click;
            MainGrid.Children.Add(buttonAjouter);

            var buttonModifier = new System.Windows.Controls.Button
            {
                Content = "Modifier Reservation",
                HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                VerticalAlignment = System.Windows.VerticalAlignment.Top,
                Margin = new System.Windows.Thickness(30, 30, 0, 0),
                Width = 250,
                Height = 150,
                FontSize = 24
            };
            Grid.SetRow(buttonModifier, 1);
            buttonModifier.Click += btn_ModifierRES_Click;
            MainGrid.Children.Add(buttonModifier);
        }
        private void btn_AjouterRES_Click(object sender, RoutedEventArgs e)
        {
            Reservation.AjouterRES ajouterRES = new Reservation.AjouterRES();
            ajouterRES.Show();
        }
        private void btn_ModifierRES_Click(object sender, RoutedEventArgs e)
        {
            Reservation.ModifierRES modifierRES = new Reservation.ModifierRES();
            modifierRES.Show();
        }
        private void btn_ListerRes_Click(object sender, RoutedEventArgs e)
        {
            Reservation.ListerRes listerRes = new Reservation.ListerRes();
            listerRes.Show();
        }

        //Chambre
        private void btn_CHAMBRE_Click(object sender, RoutedEventArgs e)
        {
            MainGrid.Children.Clear();
            var buttonLister = new System.Windows.Controls.Button
            {
                Content = "Lister Chambre",
                HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
                VerticalAlignment = System.Windows.VerticalAlignment.Center,
                Margin = new System.Windows.Thickness(30, 0, 0, 0),
                Width = 270,
                Height = 150,
                FontSize = 24
            };
            buttonLister.Click += btn_AjouterCHAMBRE_Click;
            MainGrid.Children.Add(buttonLister);
            var buttonModifier = new System.Windows.Controls.Button
            {
                Content = "Modifier Chambre",
                HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
                VerticalAlignment = System.Windows.VerticalAlignment.Center,
                Margin = new System.Windows.Thickness(0, 0, 40, 0),
                Width = 270,
                Height = 150,
                FontSize = 24
            };
            buttonModifier.Click += btn_ModifierCHAMBRE_Click;
            MainGrid.Children.Add(buttonModifier);
        }

        private void btn_AjouterCHAMBRE_Click(object sender, RoutedEventArgs e)
        {
            Chambre.AjouterCHAMBRE ajouterCHAMBRE = new Chambre.AjouterCHAMBRE();
            ajouterCHAMBRE.Show();
        }

        private void btn_ModifierCHAMBRE_Click(object sender, RoutedEventArgs e)
        {
            Chambre.ModifierCHAMBRE modifierRES = new Chambre.ModifierCHAMBRE();
            modifierRES.Show();
        }

    }

}
