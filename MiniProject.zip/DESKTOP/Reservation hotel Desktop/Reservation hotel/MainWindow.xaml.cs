﻿using System;
using System.Windows;
using Microsoft.Data.SqlClient;

namespace Reservation_hotel
{
    public partial class MainWindow : Window
    {
        // Database connection string
        private readonly string connectionString = "Server=DESKTOP-2K5N25U\\SQLEXPRESS;Database=HotelDb;Trusted_Connection=True;Encrypt=True;TrustServerCertificate=True;";

        public MainWindow()
        {
            InitializeComponent();
        }

        // Event handler for the Login button click
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string input = CodeInpute.Text.Trim();

            if (string.IsNullOrEmpty(input))
            {
                MessageBox.Show("Please enter a valid login code.");
                return;
            }

            if (input == "@admin")
            {
                // Open the Admin window
                Admin admin = new Admin();
                admin.Show();
                this.Close();
            }
            else if (input.StartsWith("@EMP"))
            {
                // Validate employee in the database
                ValidateEmployee(input);
            }
            else
            {
                MessageBox.Show("Invalid input.");
            }
        }

        // Method to validate employee in the database
        private void ValidateEmployee(string input)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM Employer WHERE CodeAdmin = @Employeecode", connection);
                    command.Parameters.AddWithValue("@Employeecode", input);

                    connection.Open();
                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        // Open the Employee window
                        EMP employe = new EMP();
                        employe.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Employee not found or invalid.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }
    }
}