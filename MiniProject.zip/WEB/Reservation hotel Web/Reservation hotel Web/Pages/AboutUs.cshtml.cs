﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Reservation_hotel.Pages
{
    public class AboutUsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
